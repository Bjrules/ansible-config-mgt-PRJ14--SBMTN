

### This project was completely forked and settings modified from uzukwuJP Github as the project was the major Bloker on this Devops Journey

 ### At this point in project 14 CI/CD beginnig of devops core.
1. Repo name: Bjrules/ansible-config-mgt-3
2. Branch: jenkinspipeline-stages..