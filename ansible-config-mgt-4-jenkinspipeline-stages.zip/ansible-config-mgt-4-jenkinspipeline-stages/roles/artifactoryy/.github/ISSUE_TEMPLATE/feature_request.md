---
name: Feature request
about: Suggest an idea for this project

---

## Proposed feature

A clear and concise description of what you want to happen.

## Rationale

Why is this feature required?

## Additional context

Add any other context about the feature request here.

Please consider [sponsoring me](https://github.com/sponsors/robertdebock).
